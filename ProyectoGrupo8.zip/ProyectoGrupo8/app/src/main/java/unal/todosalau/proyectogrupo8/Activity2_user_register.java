package unal.todosalau.proyectogrupo8;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Activity2_user_register extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_activity2_user_register);
    }
}
package unal.todosalau.proyectogrupo8;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Activity3_categoriass extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_activity3_categorias);
    }
}